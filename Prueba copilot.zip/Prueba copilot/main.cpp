#pragma once
#include <iostream>
#include "FloatClassification.h"
using namespace std;
int main() {
	string* ptrPrueba = new string();
	cout << ptrPrueba;

	return 0;
}
// soy un mamahuevo
//cambiar todos los asigned por assigned!!!!