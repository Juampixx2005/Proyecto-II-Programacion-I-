#pragma once
#include "FloatClassification.h"
#include "RouteManagement.h"
#include "FlightManagement.h"

class Interface {
public:
	void initialice();
};
