#include "Interface.h"

void Interface::initialice(){
	
}
